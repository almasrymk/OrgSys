﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Entities
{
    [Table("GeneralUnit", Schema = "admin")]
    public class GeneralUnit : BaseModel
    {
        [StringLength(50, MinimumLength = 2)]
        public virtual string? Name { get; set; }
    }
}